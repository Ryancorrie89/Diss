library(tidyverse)
library(rio)
library(psych)
library(BayesFactor)
library(apaTables)



datafile <- "Diss_new_June 15, 2022_04.16.csv"

col_names <- names(read_csv(datafile, n_max = 0))

items<- names(read_csv(datafile,skip=1, n_max=0))

names(items)<-col_names

survey<-read_csv(datafile, col_names = col_names, skip = 3)


#scoring disc 


DISC.recode<-c(
  'Forceful'='D',	'Expressive'='I',	'Restrained'='S',	'Careful'='C',
  # OOPS! We had Exiting instead of Exciting... does that matter? slightly different meaning :-)
  'Pioneering'='D',	'Exiting'='I',	'Satisfied'='S',	'Correct'='C',
  'Bold'='D',	'Animated'='I',	'Willing'='S',	'Precise'='C',
  'Argumentative'='D',	'Unpredictable'='I',	'Indecisive'='S',	'Doubting'='C',
  'Daring'='D',	'Out-going'='I',	'Patient'='S',	'Respectful'='C',
  'Self-reliant'='D',	'Persuasive'='I',	'Gentle'='S',	'Logical'='C',
  'Decisive'='D',	'Life-of-the-party'='I',	'Even-tempered'='S',	'Cautious'='C',
  'Assertive'='D',	'Popular'='I',	'Generous'='S',	'Perfectionist'='C',
  'Unyielding'='D',	'Colorful'='I',	'Easy-going'='S',	'Modest'='C',
  'Persistent'='D',	'Optimistic'='I',	'Accommodating'='S',	'Systematic'='C',
  'Relentless'='D',	'Talkative'='I',	'Neighborly'='S',	'Humble'='C',
  'Strong-willed'='D',	'Playful'='I',	'Friendly'='S',	'Observant'='C',
  'Adventurous'='D',	'Charming'='I',	'Deliberate'='S',	'Disciplined'='C',
  'Aggressive'='D',	'Attractive'='I',	'Steady'='S',	'Restrained'='C',
  'Determined'='D',	'Enthusiastic'='I',	'Sympathetic'='S',	'Analytical'='C',
  'Commanding'='D',	'Impulsive'='I',	'Slow-paced'='S',	'Critical'='C',
  'Force-of-character'='D',	'Lively'='I',	'Laid-back'='S',	'Consistent'='C',
  'Independent'='D',	'Influential'='I',	'Kind'='S',	'Orderly'='C',
  'Out-spoken'='D',	'Popular'='I',	'Pleasant'='S',	'Idealistic'='C',
  'Impatient'='D',	'Emotional'='I',	'Procrastinator'='S',	'Serious'='C',
  'Competitive'='D',	'Spontaneous'='I',	'Loyal'='S',	'Thoughtful'='C',
  'Courageous'='D',	'Convincing'='I',	'Considerate'='S',	'Self-sacrificing'='C',
  'Pushy'='D',	'Flighty'='I',	'Dependent'='S',	'Stoic'='C',
  'Directing'='D',	'Stimulating'='I',	'Tolerant'='S',	'Conventional'='C'
)

# this adds a variable containing the category for each chosen word
DISC <- survey %>%
  select(ResponseId, `DISC01`:`DISC24`) %>%
  pivot_longer(`DISC01`:`DISC24`) %>% 
  mutate(value.r=recode(value, !!!DISC.recode))

# this adds up the number of each category chosen and finds the maximum
DISC.totals<-DISC %>% 
  group_by(ResponseId, value.r) %>% 
  summarise(total=n()) %>%
  pivot_wider(names_from = value.r, values_from = total, values_fill = 0) %>% 
  mutate(max=max(C, D, I, S))

# maximum category for each person
DISC.max<-DISC.totals %>% 
  pivot_longer(C:S) %>% 
  mutate(ResponseId=ifelse(value<max,NA,ResponseId)) %>% 
  na.omit(.)

#DISC.totals instead so we have a value for each category

DISC.category<-DISC.max%>%
  pivot_wider(names_from="name", values_from="name")%>%
  unite(DISC.category,S:D, sep="/", remove=TRUE, na.rm=TRUE)%>%
  select(-max, -value)

#scoring AL


AL.recode <- c(
  "AL_1"= "self_awareness",
  "AL_5"= "self_awareness",
  "AL_9"= "self_awareness",
  "AL_13"= "self_awareness",
  "AL_2"= "internalised_moral_perspective",
  "AL_6"= "internalised_moral_perspective",
  "AL_10"= "internalised_moral_perspective",
  "AL_14"= "internalised_moral_perspective",
  "AL_3"= "balanced_processing",
  "AL_7"= "balanced_processing",
  "AL_11"= "balanced_processing",
  "AL_15"= "balanced_processing",
  "AL_4"= "relational_transparency",
  "AL_8"= "relational_transparency",
  "AL_12"= "relational_transparency",
  "AL_16"= "relational_transparency")



agree.recode <- c("Neither agree nor disagree" = 3,
                  "Somewhat agree" = 4,
                  "Strongly agree" = 5,
                  "Somewhat disagree" = 2,        
                  "Strongly disagree" = 1)


#in depth score
AL <- survey %>%
  select(ResponseId, `AL_1`:`AL_16`) %>%
  pivot_longer(`AL_1`:`AL_16`) %>% 
  mutate(value.r = recode(value, !!!agree.recode)) %>%
  mutate(ALscale=recode(name, !!!AL.recode)) %>% 
  group_by(ResponseId,ALscale) %>%
  summarise(mean=mean(value.r, na.rm=T)) %>% 
  pivot_wider(names_from = ALscale, values_from = mean)



# 1, 5, 9, and 13 (self-awareness).
# 2, 6, 10, and 14 (internalised moral perspective).
# 3, 7, 11, and 15 (balanced processing).
# 4, 8, 12, and 16 (relational transparency).


#scoring big5


revitems <- c("Big-five_6",
              "Big-five_21",
              "Big-five_31",
              "Big-five_2",
              "Big-five_12",
              "Big-five_27",
              "Big-five_37",
              "Big-five_8",
              "Big-five_18",
              "Big-five_23",
              "Big-five_43",
              "Big-five_9",
              "Big-five_24",
              "Big-five_34") 


b5.recode <- c(
  "Big-five_1"= "Extraversion",
  "Big-five_6"= "Extraversion",
  "Big-five_11"= "Extraversion",
  "Big-five_16"= "Extraversion",
  "Big-five_21"= "Extraversion",
  "Big-five_26"= "Extraversion",
  "Big-five_31"= "Extraversion", 
  "Big-five_36"= "Extraversion",
  "Big-five_3"= "Conscientiousness",
  "Big-five_8"= "Conscientiousness",
  "Big-five_13"= "Conscientiousness",
  "Big-five_18"= "Conscientiousness",
  "Big-five_23"= "Conscientiousness",
  "Big-five_28"= "Conscientiousness",
  "Big-five_33"= "Conscientiousness", 
  "Big-five_38"= "Conscientiousness",
  "Big-five_43"= "Conscientiousness",
  "Big-five_2"= "Agreeableness",
  "Big-five_7"= "Agreeableness",
  "Big-five_12"= "Agreeableness",
  "Big-five_17"= "Agreeableness",
  "Big-five_22"= "Agreeableness",
  "Big-five_27"= "Agreeableness",
  "Big-five_32"= "Agreeableness", 
  "Big-five_37"= "Agreeableness",
  "Big-five_42"= "Agreeableness",
  "Big-five_4"= "Neuroticism",
  "Big-five_9"= "Neuroticism",
  "Big-five_14"= "Neuroticism",
  "Big-five_19"= "Neuroticism",
  "Big-five_24"= "Neuroticism",
  "Big-five_29"= "Neuroticism",
  "Big-five_34"= "Neuroticism", 
  "Big-five_39"= "Neuroticism",
  "Big-five_5"= "Openness",
  "Big-five_10"= "Openness",
  "Big-five_15"= "Openness",
  "Big-five_20"= "Openness",
  "Big-five_25"= "Openness",
  "Big-five_30"= "Openness",
  "Big-five_35"= "Openness", 
  "Big-five_40"= "Openness",
  "Big-five_41"= "Openness",
  "Big-five_44"= "Openness")

#   Agreeableness: "Big-five_2, "Big-five_7, "Big-five_12, "Big-five_17, "Big-five_22, "Big-five_27, "Big-five_32, "Big-five_37, "Big-five_42 
#   Conscientiousness: "Big-five_3, "Big-five_8, "Big-five_13, "Big-five_18, "Big-five_23, "Big-five_28, "Big-five_33, "Big-five_38, "Big-five_43 
#   Neuroticism: "Big-five_4, "Big-five_9, "Big-five_14, "Big-five_19, "Big-five_24, "Big-five_29, "Big-five_34, "Big-five_39 
#   Openness: "Big-five_5, "Big-five_10, "Big-five_15, "Big-five_20, "Big-five_25, "Big-five_30, "Big-five_35, "Big-five_40, "Big-five_41, "Big-five_44
# )

big5 <- survey %>%
  select(ResponseId, `Big-five_1`:`Big-five_44`) %>%
  pivot_longer(`Big-five_1`:`Big-five_44`) %>%
  mutate(value.r = recode(value, !!!agree.recode)) %>%
  mutate(b5scale=recode(name, !!!b5.recode)) %>%
  mutate(value.r2=case_when(name %in% revitems ~ 6-value.r, TRUE ~ value.r)) %>%
  group_by(ResponseId,b5scale) %>%
  summarise(mean=mean(value.r2, na.rm=T)) %>% 
  pivot_wider(names_from = b5scale, values_from=mean)


# Extraversion: 1, 6R, 11, 16, 21R, 26, 31R, 36 
# Agreeableness: 2R, 7, 12R, 17, 22, 27R, 32, 37R, 42 
# Conscientiousness: 3, 8R, 13, 18R, 23R, 28, 33, 38, 43R 
# Neuroticism: 4, 9R, 14, 19, 24R, 29, 34R, 39 
# Openness: 5, 10, 15, 20, 25, 30, 35R, 40, 41R, 44 


score
final.data<-full_join(big5,AL)
final.data<-full_join(final.data, DISC.totals)
final.data<-full_join(final.data, DISC.category)
final.data<-left_join(final.data, survey %>% select(ResponseId,Sex))

final.data <- final.data %>%
  mutate(AL=(relational_transparency + self_awareness + internalised_moral_perspective + balanced_processing)/4)

#correlations and descriptives
apa.cor.table(final.data %>% select(-ResponseId, -max, -relational_transparency, -self_awareness, -internalised_moral_perspective, -balanced_processing), filename="ALTable.doc")



#AL and B5 plots

ALB5plots %>% glimpse

final.data %>% filter(DISC.category %in% c("D","I","S","C")) %>% 
  ggplot(aes(x=internalised_moral_perspective, y=Conscientiousness, 
             colour=DISC.category, group=DISC.category))+
  geom_point()+
  geom_smooth(method="lm", se=F)+
  theme_classic()




#AL and DISC
ggpubr

ALB5plots<-full_join(AL, big5)
ALdiscplot<-full_join(AL, DISC.totals)


ALdiscplot <- ALdiscplot %>%
  mutate(ResponseId = factor(ResponseId))

ALdiscplot %>% glimpse
ALdiscplot %>% head

ALdiscplot %>% 
  ggviolin(x = "r" , y = "D", "i", "s", "c", desc_stat = "mean_se") +
  xlab("Aesthetic value group")



#balanced_processing
final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=balanced_processing))+
  geom_violin()+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylim(1,5)+
  theme_classic()

oneway.test(data=final.data%>% filter(DISC.category %in% c("S","C","I","D")), 
            formula=balanced_processing ~ DISC.category)
p-value = 0.9892
# to report anova
# F(3,18.879)=.04, p=.989

#F = 0.039413, num df = 3.000, denom df = 18.879, p-value = 0.9892



#internalised_moral_perspective

final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=internalised_moral_perspective))+
  geom_violin()+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylim(1,5)+
  theme_classic()

final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=al))+
  geom_violin()+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylim(1,5)+
  theme_classic()

oneway.test(data=final.data%>% filter(DISC.category %in% c("S","C","I","D")), 
            formula=internalised_moral_perspective ~ DISC.category)
describeBy(final.data$internalised_moral_perspective, group=final.data$DISC.category)

#p-value = 0.05345 
#anova
#F(3,19.72)=.03, p=0.053

#F = 3.035, num df = 3.00, denom df = 19.72, p-value = 0.05345



#relational_transparency

final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=relational_transparency))+
  geom_violin()+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylim(1,5)+
  theme_classic()

oneway.test(data=final.data%>% filter(DISC.category %in% c("D","I","S","C")), 
            formula=relational_transparency ~ DISC.category)
describeBy(final.data$relational_transparency, group=final.data$DISC.category)

#p-value = 0.04396
#anova
#F(3,18.886)=0.3, P=0.04396 

#F = 3.2717, num df = 3.000, denom df = 18.886, p-value = 0.04396

final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=al))+
  geom_violin()+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylim(1,5)+
  theme_classic()

oneway.test(data=final.data%>% filter(DISC.category %in% c("D","I","S","C")), 
            formula=al ~ DISC.category)
describeBy(final.data$al, group=final.data$DISC.category)

#self_awareness

final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=self_awareness))+
  geom_violin()+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylim(1,5)+
  theme_classic()

oneway.test(data=final.data%>% filter(DISC.category %in% c("D","I","S","C")), 
            formula=self_awareness ~ DISC.category)
describeBy(final.data$self_awareness, group=final.data$DISC.category)

#p-value = 0.1497 
#anova
#F(3, 18.105)=0.2, P=0.1497

#F = 2.0016, num df = 3.000, denom df = 18.105, p-value = 0.1497

final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=al))+
  geom_violin()+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylim(1,5)+
  theme_classic()

oneway.test(data=final.data%>% filter(DISC.category %in% c("D","I","S","C")), 
            formula=al ~ DISC.category)
describeBy(final.data$al, group=final.data$DISC.category)


#t-test on the DISC means 


t.test(data=final.data%>% filter(DISC.category %in% c("D", "I")), 
       formula=relational_transparency ~ DISC.category)

#new 

tdata<-final.data%>%
  filter(DISC.category %in% c("S", "C")) %>%
  mutate(DISC.category=factor(DISC.category)) 
t.test(tdata, relational_transparency ~ DISC.category)

with(final.data, t.test(relational_transparency[DISC.category == "D"], 
                        relational_transparency[DISC.category == "I"]))


#D AND I with relational_transparency

#t = 0.56766, df = 13.946, p-value = 0.5793

#S AND C with relational_transparency
#t = 3.0406, df = 46.657, p-value = 0.003865

#C AND I with relational_transparency
#t = -1.8631, df = 12.587, p-value = 0.08594

#C AND D with relational_transparency
#t = -2.2424, df = 13.551, p-value = 0.04223

#D AND S with relational_transparency
#t = 0.50628, df = 10.156, p-value = 0.6235


tdata<-final.data%>%
  filter(DISC.category %in% c("C", "D")) %>%
  mutate(DISC.category=factor(DISC.category)) 
t.test(tdata, self_awareness ~ DISC.category)

with(final.data, t.test(relational_transparency[DISC.category == "C"], 
                        relational_transparency[DISC.category == "D"]))

#t = -0.41109, df = 13.967, p-value = 0.6872


final.data %>% ungroup() %>%
  select(Openness, Conscientiousness, Agreeableness, Neuroticism, Extraversion, al) %>%
  pivot_longer(!al) %>%
  rename("Big5 factor"="name", "Authentic Leadership" ="al", "Subscale score" = "value") %>%
  ggplot(aes(x=`Subscale score`, y=`Authentic Leadership`, colour=`Big5 factor`, group= `Big5 factor`)) +
  geom_point() +
  geom_smooth(method=lm, se=F) +
  theme_classic()


#aldisc
final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=al))+
  geom_violin()+
  geom_boxplot(width=0.2)+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylab("Autentic Leadership") + xlab("DISC catagory")+
  ylim(1,5)+
  theme_classic()


model<- lm(data=final.data, formula = al~Openness + Conscientiousness + Agreeableness + Neuroticism + Extraversion)
summary(model)

#relational_transparency single plot

final.data %>% filter(DISC.category %in% c("S","C","I","D"))%>%
  filter(!Sex=="Prefer not to say")%>%
  ggplot(aes(x=as.factor(DISC.category), y=relational_transparency))+
  geom_violin()+
  geom_jitter(aes(colour=Sex),width=.2) +
  ylim(1,5)+
  theme_classic()

oneway.test(data=final.data%>% filter(DISC.category %in% c("D","I","S","C")), 
            formula=relational_transparency ~ DISC.category)
describeBy(final.data$relational_transparency, group=final.data$DISC.category)

#p-value = 0.04396
#anova
#F(3,18.886)=0.3, P=0.04396 